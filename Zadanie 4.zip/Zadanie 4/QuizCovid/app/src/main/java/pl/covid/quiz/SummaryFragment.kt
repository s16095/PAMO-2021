package pl.covid.quiz

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager

class SummaryFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_summary, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val points = requireArguments().getInt("points")
        val size = requireArguments().getInt("size")
        val summaryResult = view.findViewById<TextView>(R.id.summaryResult)
        summaryResult.text = "Twoj wynik: $points / $size"
        view.findViewById<View>(R.id.summaryClose).setOnClickListener { view1: View? -> parentFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE) }
    }

    companion object {
        fun newInstance(points: Int, size: Int): Fragment {
            val fragment = SummaryFragment()
            val bundle = Bundle()
            bundle.putInt("points", points)
            bundle.putInt("size", size)
            fragment.arguments = bundle
            return fragment
        }
    }
}