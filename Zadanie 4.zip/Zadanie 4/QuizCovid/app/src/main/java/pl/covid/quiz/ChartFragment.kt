package pl.covid.quiz

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import java.util.*

class ChartFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_chart, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val chart1: BarChart = view.findViewById(R.id.chart1)
        setupChart(chart1, 1000, 2000f, 12657f)
        val chart2: BarChart = view.findViewById(R.id.chart2)
        setupChart(chart2, 1000, 500f, 1200f)
        val chart3: BarChart = view.findViewById(R.id.chart3)
        setupChart(chart3, 1000, 1000f, 145f)
    }

    private fun setupChart(chart: BarChart, polandValue: Int, germanyValue: Float, franceValue: Float) {
        chart.description.isEnabled = false
        val valuesPoland = ArrayList<BarEntry>()
        valuesPoland.add(BarEntry(0.toFloat(), polandValue.toFloat()))
        val valuesGermany = ArrayList<BarEntry>()
        valuesGermany.add(BarEntry(1.toFloat(), germanyValue.toFloat()))
        val valuesFrance = ArrayList<BarEntry>()
        valuesFrance.add(BarEntry(2.toFloat(), franceValue.toFloat()))
        val setPoland: BarDataSet
        val setGermany: BarDataSet
        val setFrance: BarDataSet
        if (chart.data != null && chart.data.dataSetCount > 0) {
            setPoland = chart.data.getDataSetByIndex(0) as BarDataSet
            setPoland.values = valuesPoland
            setGermany = chart.data.getDataSetByIndex(1) as BarDataSet
            setGermany.values = valuesPoland
            setFrance = chart.data.getDataSetByIndex(2) as BarDataSet
            setFrance.values = valuesFrance
            chart.data.notifyDataChanged()
            chart.notifyDataSetChanged()
        } else {
            setPoland = BarDataSet(valuesPoland, "Polska")
            setPoland.setDrawIcons(false)
            setPoland.color = Color.RED
            setGermany = BarDataSet(valuesGermany, "Niemcy")
            setGermany.setDrawIcons(false)
            setGermany.color = Color.GREEN
            setFrance = BarDataSet(valuesFrance, "Francja")
            setFrance.setDrawIcons(false)
            setFrance.color = Color.BLUE
            val dataSets = ArrayList<IBarDataSet>()
            dataSets.add(setPoland)
            dataSets.add(setGermany)
            dataSets.add(setFrance)
            val data = BarData(dataSets)
            data.setValueTextSize(10f)
            data.barWidth = 0.9f
            chart.data = data
        }
        val l = chart.legend
        l.verticalAlignment = Legend.LegendVerticalAlignment.TOP
        l.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
        l.orientation = Legend.LegendOrientation.HORIZONTAL
        l.setDrawInside(false)
        l.form = Legend.LegendForm.SQUARE
        l.formSize = 9f
        l.textSize = 11f
        l.xEntrySpace = 4f
    }
}