package pl.covid.quiz

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import pl.covid.quiz.model.QuizItem
import java.util.*

class QuizFragment : Fragment() {
    private var currentIndex = 0
    private val items = createItems()
    private val answers: MutableMap<String, Int?> = HashMap()
    private var q: TextView? = null
    private var qg: RadioGroup? = null
    private var a1: RadioButton? = null
    private var a2: RadioButton? = null
    private var a3: RadioButton? = null
    private fun createItems(): List<QuizItem> {
        val items: MutableList<QuizItem> = ArrayList()
        items.add(QuizItem(
                "Jaką nazwę nosi nowy koronawirus?",
                "SARS-CoV",
                "SARS-CoV-2",
                "COVID-19",
                2))
        items.add(QuizItem(
                "Koronawirus - skąd się wzięła taka nazwa?",
                "Od nazwiska odkrywcy",
                "Od wypustek na osłonce wirusa przypominających koronę (łac. corona - korona, wieniec)",
                "Od nowojorskiego rejonu Corona, w którym po raz pierwszy odkryto koronawirusy",
                2))
        items.add(QuizItem(
                "Gdzie odnotowano pierwsze przypadki zakażeń?",
                "Pekin",
                "Wuhan",
                "Rzym",
                2))
        items.add(QuizItem(
                "Który zestaw objawów jest najbardziej charakterystyczny dla COVID-19?",
                "Bezdech, kołatanie serca, zaburzenia czucia",
                "Gorączka, kaszel, duszności, zmęczenie",
                "Biegunka, wymioty, osłabienie łaknienia",
                2))
        items.add(QuizItem(
                "Ciężka postać COVID-19 to:",
                "Zapalenie płuc i niewydolność oddechowa",
                "Uszkodzenia ośrodkowego układu nerwowego",
                "Gorączka krwotoczna",
                1))
        items.add(QuizItem(
                "Nowy koronawirus rozprzestrzenia się:",
                "drogą pokarmową",
                "drogą kropelkową",
                "drogą kontaktu z zakażoną krwią",
                1))
        return items
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_quiz, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        q = view.findViewById(R.id.q)
        qg = view.findViewById(R.id.qg)
        a1 = view.findViewById(R.id.a1)
        a2 = view.findViewById(R.id.a2)
        a3 = view.findViewById(R.id.a3)
        val prevBtn = view.findViewById<Button>(R.id.prevBtn)
        prevBtn.setOnClickListener { view1: View? -> prevPressed() }
        val nextBtn = view.findViewById<Button>(R.id.nextBtn)
        nextBtn.setOnClickListener { view1: View? -> nextPressed() }
    }

    private fun nextPressed() {
        val selectedAnswerId = qg!!.checkedRadioButtonId
        val question = items[currentIndex].question
        when (selectedAnswerId) {
            R.id.a1 -> answers[question] = 1
            R.id.a2 -> answers[question] = 2
            R.id.a3 -> answers[question] = 3
            else -> answers[question] = null
        }
        if (currentIndex != items.size - 1) {
            qg!!.clearCheck()
            currentIndex++
            showQuestion(items[currentIndex])
        } else {
            var points = 0
            for (quizItem in items) {
                val userAnswer = answers[quizItem.question]
                if (userAnswer != null && userAnswer == quizItem.correctAnswer) {
                    points++
                }
            }
            openSummaryFragment(points, items.size)
        }
    }

    private fun openSummaryFragment(points: Int, size: Int) {
        parentFragmentManager
                .beginTransaction()
                .replace(R.id.root, SummaryFragment.newInstance(points, size))
                .addToBackStack("SummaryFragment")
                .commit()
    }

    private fun showQuestion(quizItem: QuizItem) {
        q!!.text = quizItem.question
        a1!!.text = quizItem.a1
        a2!!.text = quizItem.a2
        a3!!.text = quizItem.a3
        val userAnswer = answers[quizItem.question]
        if (userAnswer != null) {
            when (userAnswer) {
                1 -> a1!!.isChecked = true
                2 -> a2!!.isChecked = true
                3 -> a3!!.isChecked = true
            }
        }
    }

    private fun prevPressed() {
        val selectedAnswerId = qg!!.checkedRadioButtonId
        val question = items[currentIndex].question
        when (selectedAnswerId) {
            R.id.a1 -> answers[question] = 1
            R.id.a2 -> answers[question] = 2
            R.id.a3 -> answers[question] = 3
            else -> answers[question] = null
        }
        if (currentIndex != 0) {
            qg!!.clearCheck()
            currentIndex--
            showQuestion(items[currentIndex])
        } else {
            parentFragmentManager.popBackStack()
        }
    }
}