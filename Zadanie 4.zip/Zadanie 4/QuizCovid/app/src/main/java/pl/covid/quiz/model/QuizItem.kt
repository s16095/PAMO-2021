package pl.covid.quiz.model

class QuizItem(val question: String, val a1: String, val a2: String, val a3: String, val correctAnswer: Int)