package pl.covid.quiz

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class MenuFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<View>(R.id.menuChart).setOnClickListener { view1: View? -> openChartFragment() }
        view.findViewById<View>(R.id.menuQuiz).setOnClickListener { view1: View? -> openQuizFragment() }
    }

    private fun openQuizFragment() {
        parentFragmentManager
                .beginTransaction()
                .replace(R.id.root, QuizFragment())
                .addToBackStack("QuizFragment")
                .commit()
    }

    private fun openChartFragment() {
        parentFragmentManager
                .beginTransaction()
                .replace(R.id.root, ChartFragment())
                .addToBackStack("ChartFragment")
                .commit()
    }
}