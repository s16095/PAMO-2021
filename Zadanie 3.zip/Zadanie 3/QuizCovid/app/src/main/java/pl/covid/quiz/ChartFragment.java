package pl.covid.quiz;


import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;

import java.util.ArrayList;

public class ChartFragment extends Fragment {


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_chart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        BarChart chart1 = view.findViewById(R.id.chart1);
        setupChart(chart1, 1000, 2000, 12657);

        BarChart chart2 = view.findViewById(R.id.chart2);
        setupChart(chart2, 1000, 500, 1200);

        BarChart chart3 = view.findViewById(R.id.chart3);
        setupChart(chart3, 1000, 1000, 145);

    }

    private void setupChart(BarChart chart, int polandValue, float germanyValue, float franceValue) {
        chart.getDescription().setEnabled(false);


        ArrayList<BarEntry> valuesPoland = new ArrayList<>();
        valuesPoland.add(new BarEntry(0, polandValue));

        ArrayList<BarEntry> valuesGermany = new ArrayList<>();
        valuesGermany.add(new BarEntry(1, germanyValue));

        ArrayList<BarEntry> valuesFrance = new ArrayList<>();
        valuesFrance.add(new BarEntry(2, franceValue));


        BarDataSet setPoland;
        BarDataSet setGermany;
        BarDataSet setFrance;

        if (chart.getData() != null && chart.getData().getDataSetCount() > 0) {

            setPoland = (BarDataSet) chart.getData().getDataSetByIndex(0);
            setPoland.setValues(valuesPoland);

            setGermany = (BarDataSet) chart.getData().getDataSetByIndex(1);
            setGermany.setValues(valuesPoland);

            setFrance = (BarDataSet) chart.getData().getDataSetByIndex(2);
            setFrance.setValues(valuesFrance);

            chart.getData().notifyDataChanged();
            chart.notifyDataSetChanged();

        } else {
            setPoland = new BarDataSet(valuesPoland, "Polska");
            setPoland.setDrawIcons(false);
            setPoland.setColor(Color.RED);

            setGermany = new BarDataSet(valuesGermany, "Niemcy");
            setGermany.setDrawIcons(false);
            setGermany.setColor(Color.GREEN);

            setFrance = new BarDataSet(valuesFrance, "Francja");
            setFrance.setDrawIcons(false);
            setFrance.setColor(Color.BLUE);


            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(setPoland);
            dataSets.add(setGermany);
            dataSets.add(setFrance);

            BarData data = new BarData(dataSets);
            data.setValueTextSize(10f);
            data.setBarWidth(0.9f);

            chart.setData(data);
        }

        Legend l = chart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
        l.setForm(Legend.LegendForm.SQUARE);
        l.setFormSize(9f);
        l.setTextSize(11f);
        l.setXEntrySpace(4f);
    }
}
