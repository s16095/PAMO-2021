package pl.covid.quiz;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MenuFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_menu, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.menuChart).setOnClickListener(view1 -> openChartFragment());
        view.findViewById(R.id.menuQuiz).setOnClickListener(view1 -> openQuizFragment());
    }

    private void openQuizFragment() {
        getParentFragmentManager()
                .beginTransaction()
                .replace(R.id.root, new QuizFragment())
                .addToBackStack("QuizFragment")
                .commit();
    }

    private void openChartFragment() {
        getParentFragmentManager()
                .beginTransaction()
                .replace(R.id.root, new ChartFragment())
                .addToBackStack("ChartFragment")
                .commit();
    }
}
