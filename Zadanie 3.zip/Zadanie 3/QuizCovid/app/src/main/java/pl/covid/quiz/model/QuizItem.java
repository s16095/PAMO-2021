package pl.covid.quiz.model;


public class QuizItem {

    private final String question;
    private final String a1;
    private final String a2;
    private final String a3;
    private final int correctAnswer;

    public QuizItem(String question, String a1, String a2, String a3, int correctAnswer) {
        this.question = question;
        this.a1 = a1;
        this.a2 = a2;
        this.a3 = a3;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public String getA1() {
        return a1;
    }

    public String getA2() {
        return a2;
    }

    public String getA3() {
        return a3;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }
}
