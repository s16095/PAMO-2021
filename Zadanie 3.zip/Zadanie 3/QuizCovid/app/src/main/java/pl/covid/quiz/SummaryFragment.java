package pl.covid.quiz;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class SummaryFragment extends Fragment {

    public static Fragment newInstance(int points, int size) {
        SummaryFragment fragment = new SummaryFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("points", points);
        bundle.putInt("size", size);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_summary, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        int points = requireArguments().getInt("points");
        int size = requireArguments().getInt("size");

        TextView summaryResult = view.findViewById(R.id.summaryResult);
        summaryResult.setText("Twoj wynik: " + points + " / " + size);

        view.findViewById(R.id.summaryClose).setOnClickListener(view1 -> getParentFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE));

    }

}
