package pl.covid.quiz;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pl.covid.quiz.model.QuizItem;

public class QuizFragment extends Fragment {

    private int currentIndex = 0;

    private final List<QuizItem> items = createItems();
    private final Map<String, Integer> answers = new HashMap<>();

    private TextView q;
    private RadioGroup qg;
    private RadioButton a1, a2, a3;

    private List<QuizItem> createItems() {
        List<QuizItem> items = new ArrayList<>();
        items.add(new QuizItem(
                "Jaką nazwę nosi nowy koronawirus?",
                "SARS-CoV",
                "SARS-CoV-2",
                "COVID-19",
                2));
        items.add(new QuizItem(
                "Koronawirus - skąd się wzięła taka nazwa?",
                "Od nazwiska odkrywcy",
                "Od wypustek na osłonce wirusa przypominających koronę (łac. corona - korona, wieniec)",
                "Od nowojorskiego rejonu Corona, w którym po raz pierwszy odkryto koronawirusy",
                2));
        items.add(new QuizItem(
                "Gdzie odnotowano pierwsze przypadki zakażeń?",
                "Pekin",
                "Wuhan",
                "Rzym",
                2));
        items.add(new QuizItem(
                "Który zestaw objawów jest najbardziej charakterystyczny dla COVID-19?",
                "Bezdech, kołatanie serca, zaburzenia czucia",
                "Gorączka, kaszel, duszności, zmęczenie",
                "Biegunka, wymioty, osłabienie łaknienia",
                2));

        items.add(new QuizItem(
                "Ciężka postać COVID-19 to:",
                "Zapalenie płuc i niewydolność oddechowa",
                "Uszkodzenia ośrodkowego układu nerwowego",
                "Gorączka krwotoczna",
                1));
        items.add(new QuizItem(
                "Nowy koronawirus rozprzestrzenia się:",
                "drogą pokarmową",
                "drogą kropelkową",
                "drogą kontaktu z zakażoną krwią",
                1));
        return items;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_quiz, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        q = view.findViewById(R.id.q);
        qg = view.findViewById(R.id.qg);
        a1 = view.findViewById(R.id.a1);
        a2 = view.findViewById(R.id.a2);
        a3 = view.findViewById(R.id.a3);

        Button prevBtn = view.findViewById(R.id.prevBtn);
        prevBtn.setOnClickListener(view1 -> prevPressed());
        Button nextBtn = view.findViewById(R.id.nextBtn);
        nextBtn.setOnClickListener(view1 -> nextPressed());
    }

    private void nextPressed() {
        int selectedAnswerId = qg.getCheckedRadioButtonId();

        String question = items.get(currentIndex).getQuestion();

        switch (selectedAnswerId) {
            case R.id.a1:
                answers.put(question, 1);
                break;
            case R.id.a2:
                answers.put(question, 2);
                break;
            case R.id.a3:
                answers.put(question, 3);
                break;
            default:
                answers.put(question, null);
        }


        if (currentIndex != items.size() - 1) {
            qg.clearCheck();
            currentIndex++;
            showQuestion(items.get(currentIndex));
        } else {
            int points = 0;
            for (QuizItem quizItem : items) {
                Integer userAnswer = answers.get(quizItem.getQuestion());
                if (userAnswer != null && userAnswer == quizItem.getCorrectAnswer()) {
                    points++;
                }
            }
            openSummaryFragment(points, items.size());
        }

    }

    private void openSummaryFragment(int points, int size) {
        getParentFragmentManager()
                .beginTransaction()
                .replace(R.id.root, SummaryFragment.newInstance(points, size))
                .addToBackStack("SummaryFragment")
                .commit();
    }

    private void showQuestion(QuizItem quizItem) {
        q.setText(quizItem.getQuestion());
        a1.setText(quizItem.getA1());
        a2.setText(quizItem.getA2());
        a3.setText(quizItem.getA3());
        Integer userAnswer = answers.get(quizItem.getQuestion());
        if (userAnswer != null) {
            switch (userAnswer) {
                case 1:
                    a1.setChecked(true);
                    break;
                case 2:
                    a2.setChecked(true);
                    break;
                case 3:
                    a3.setChecked(true);
                    break;
            }
        }
    }

    private void prevPressed() {
        int selectedAnswerId = qg.getCheckedRadioButtonId();
        String question = items.get(currentIndex).getQuestion();

        switch (selectedAnswerId) {
            case R.id.a1:
                answers.put(question, 1);
                break;
            case R.id.a2:
                answers.put(question, 2);
                break;
            case R.id.a3:
                answers.put(question, 3);
                break;
            default:
                answers.put(question, null);
        }

        if (currentIndex != 0) {
            qg.clearCheck();
            currentIndex--;
            showQuestion(items.get(currentIndex));
        } else {
            getParentFragmentManager().popBackStack();
        }
    }
}
